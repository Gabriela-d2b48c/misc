/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_big.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 12:19:05 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 12:21:23 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static int	is_higher_than_median(t_list1 *head, int median)
{
	while (head)
	{
		if (head->number > median)
			return (1);
		head = head->next;
	}
	return (0);
}

static void	partition_to_b(t_list1 **head_a, t_list1 **head_b, int median)
{
	int size;
	int i;

	size = ft_lstsize_push_swap(*head_a);
	i = 0;
	while (i < size && is_higher_than_median(*head_a, median))
	{
		if ((*head_a)->number <= median)
		{
			pb(head_a, head_b);
			size--;
		}
		else
		{
			ra(head_a, 1);
			i++;
		}
	}
}

static void	partition_to_a(t_list1 **head_a, t_list1 **head_b)
{
	int	size;
	int	i;

	size = ft_lstsize_push_swap(*head_b);
	i = 0;
	while (i < size)
	{
		if ((*head_b)->number == find_largest(head_b))
		{
			pa(head_a, head_b);
			size--;
		}
		else
		{
			rb(head_b, 1);
			i++;
		}
	}
}

void	ft_sort_big(t_list1 **head_a, t_list1 **head_b)
{
	int median;

	while (ft_lstsize_push_swap(*head_a) > 5)
	{
		median = find_smallest(head_a) + (find_largest(head_a) - find_smallest(head_a)) / 2;
		partition_to_b(head_a, head_b, median);
	}
	ft_sort_five(head_a, head_b);
	partition_to_a(head_a, head_b);
}