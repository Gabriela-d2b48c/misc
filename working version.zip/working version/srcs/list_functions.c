/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   list_functions.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:24:23 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 11:27:02 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

t_list1	*ft_lstnew_push_swap(int content)
{
	t_list1	*new;

	new = (t_list1 *)malloc(sizeof(t_list1));
	if (!new)
		return (NULL);
	new->number = content;
	new->index = 0;
	new->next = NULL;
	return (new);
}

void	ft_lstadd_back_push_swap(t_list1 **lst, t_list1 *new)
{
	if (!lst || !new)
		return;
	if (!*lst)
		*lst = new;
	else
	{
		t_list1 *last = ft_lstlast_push_swap(*lst);
		last->next = new;
	}
}

t_list1 *ft_lstlast_push_swap(t_list1 *lst)
{
	if (!lst)
		return (NULL);
	while (lst->next)
		lst = lst->next;
	return (lst);
}

int	ft_lstsize_push_swap(t_list1 *lst)
{
	int size;

	size = 0;
	while (lst)
	{
		size++;
		lst = lst->next;
	}
	return (size);
}

void	ft_lstadd_front_push_swap(t_list1 **lst, t_list1 *new)
{
	if (!lst || !new)
		return;
	new->next = *lst;
	*lst = new;
}