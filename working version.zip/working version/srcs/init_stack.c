/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_stack.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:00:15 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 11:19:38 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int init_stack_a(char *argv[], t_list1 **head_a)
{
	char	**arr;
	int		i;

	i = 1;
	*head_a = NULL;
	while (argv[i])
	{
		arr = ft_split(argv[i], ' ');
		int	j = 0;
		while (arr[j])
		{
			if (error_handling(arr[j], head_a))
			{
				ft_free_lst(head_a);
				ft_free_arr(arr);
				return (1);
			}
			ft_lstadd_back_push_swap(head_a, ft_lstnew_push_swap(ft_atoi(arr[j])));
			ft_get_indx(ft_lstlast_push_swap(*head_a), head_a);
			j++;
		}
		ft_free_arr(arr);
		i++;
	}
	return (0);
}
