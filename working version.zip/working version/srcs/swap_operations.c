/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   swap_operations.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:55:19 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 11:56:45 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	sa(t_list1 **head_a, int flag)
{
	int tmp;

	if (*head_a && (*head_a)->next)
	{
		tmp = (*head_a)->number;
		(*head_a)->number = (*head_a)->next->number;
		(*head_a)->next->number = tmp;
		if (flag)
			write(1, "sa\n", 3);
	}
}

void	sb(t_list1 **head_b, int flag)
{
	int	tmp;

	if (*head_b && (*head_b)->next)
	{
		tmp = (*head_b)->number;
		(*head_b)->number = (*head_b)->next->number;
		(*head_b)->next->number = tmp;
		if (flag)
			write(1, "sb\n", 3);
	}
}

void ss(t_list1 **head_a, t_list1 **head_b)
{
	sa(head_a, 0);
	sb(head_b, 0);
	write(1, "ss\n", 3);
}
