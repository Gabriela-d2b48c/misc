/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_operations.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:27:30 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 11:28:29 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void pa(t_list1 **head_a, t_list1 **head_b)
{
	if (*head_b)
	{
		t_list1 *tmp = *head_b;
		*head_b = (*head_b)->next;
		ft_lstadd_front_push_swap(head_a, tmp);
		write(1, "pa\n", 3);
	}
}

void pb(t_list1 **head_a, t_list1 **head_b)
{
	if (*head_a)
	{
		t_list1 *tmp = *head_a;
		*head_a = (*head_a)->next;
		ft_lstadd_front_push_swap(head_b, tmp);
		write(1, "pb\n", 3);
	}
}
