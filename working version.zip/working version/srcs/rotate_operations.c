/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rotate_operations.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:33:48 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 11:34:59 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	ra(t_list1 **head_a, int flag)
{
	if (*head_a && (*head_a)->next)
	{
		t_list1 *first = *head_a;
		*head_a = first->next;
		first->next = NULL;
		ft_lstadd_back_push_swap(head_a, first);
	}
	if (flag)
		write(1, "ra\n", 3);
}

void	rb(t_list1 **head_b, int flag)
{
	if (*head_b && (*head_b)->next)
	{
		t_list1 *first = *head_b;
		*head_b = first->next;
		first->next = NULL;
		ft_lstadd_back_push_swap(head_b, first);
	}
	if (flag)
		write(1, "rb\n", 3);
}

void	rr(t_list1 **head_a, t_list1 **head_b) {
	ra(head_a, 0);
	rb(head_b, 0);
	write(1, "rr\n", 3);
}