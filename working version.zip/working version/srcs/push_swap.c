/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:28:52 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 11:30:40 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	main(int argc, char *argv[])
{
	t_list1 *head_a;
	t_list1 *head_b;

	if (argc == 1)
		return (0);
	if (init_stack_a(argv, &head_a))
	{
		write(2, "Error\n", 6);
		return (1);
	}
	head_b = NULL;
	push_swap(&head_a, &head_b);
	ft_free_lst(&head_a);
	return (0);
}

int	push_swap(t_list1 **head_a, t_list1 **head_b)
{
	if (is_sorted(head_a))
		return (0);
	int size = ft_lstsize_push_swap(*head_a);
	if (size <= 3)
		ft_sort_three(head_a);
	else if (size <= 5)
		ft_sort_five(head_a, head_b);
	else
		ft_sort_big(head_a, head_b);
	return (0);
}