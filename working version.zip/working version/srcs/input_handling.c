/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input_handling.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:19:51 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 12:23:13 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	error_handling(char *str, t_list1 **head_a)
{
	int			i;
	long long	num;

	i = 0;
	if (str[i] == '-' || str[i] == '+')
		i++;
	if (str[i] == '\0')
		return (1);
	while (str[i]) {
		if (!ft_isdigit(str[i]))
			return (1);
		i++;
	}
	num = ft_atoi(str);
	if (num > INT_MAX || num < INT_MIN)
		return (1);
	if (ft_lstsize_push_swap(*head_a) != 0)
	{
		t_list1 *tmp = *head_a;
		while (tmp)
		{
			if (tmp->number == num)
				return (1);
			tmp = tmp->next;
		}
	}
	return (0);
}

void ft_get_indx(t_list1 *node, t_list1 **head_a) {
	t_list1 *tmp;
	int i;

	i = 0;
	tmp = *head_a;
	while (tmp)
	{
		if (tmp->number < node->number)
			i++;
		tmp = tmp->next;
	}
	node->index = i;
}