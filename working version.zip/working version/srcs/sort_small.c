/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_small.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:38:01 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 11:49:12 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	ft_sort_three(t_list1 **head_a)
{
	if ((*head_a)->number > (*head_a)->next->number)
	{
		if ((*head_a)->next->next->number > (*head_a)->number)
			sa(head_a, 1);
		else if ((*head_a)->next->next->number > (*head_a)->next->number)
			rra(head_a, 1);
		else
		{
			sa(head_a, 1);
			ra(head_a, 1);
		}
	} 
	else 
	{
		if ((*head_a)->next->next->number > (*head_a)->number)
			ra(head_a, 1);
		else if ((*head_a)->next->next->number > (*head_a)->next->number)
		{
			sa(head_a, 1);
			rra(head_a, 1);
		}
	}
}

void	ft_sort_five(t_list1 **head_a, t_list1 **head_b)
{
	int smallest;
	int pushed_count;

	pushed_count = 0;
	while (pushed_count < 2)
	{
		smallest = find_smallest(head_a);
	while ((*head_a)->number != smallest)
			ra(head_a, 1);
		pb(head_a, head_b);
		pushed_count++;
	}
	ft_sort_three(head_a);
	if ((*head_b)->number < (*head_b)->next->number)
		sb(head_b, 1);
	pushed_count = 0;
	while (pushed_count < 2)
	{
		pa(head_a, head_b);
		pushed_count++;
	}
}