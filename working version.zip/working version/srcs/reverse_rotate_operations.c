/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   reverse_rotate_operations.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:31:18 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 11:33:13 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	rra(t_list1 **head_a, int flag)
{
	if (*head_a && (*head_a)->next) {
		t_list1 *prev_last = NULL;
		t_list1 *last = *head_a;
		while (last->next)
		{
			prev_last = last;
			last = last->next;
		}
		prev_last->next = NULL;
		last->next = *head_a;
		*head_a = last;
	}
	if (flag)
		write(1, "rra\n", 4);
}

void	rrb(t_list1 **head_b, int flag)
{
	if (*head_b && (*head_b)->next)
	{
		t_list1 *prev_last = NULL;
		t_list1 *last = *head_b;
		while (last->next)
		{
			prev_last = last;
			last = last->next;
		}
		prev_last->next = NULL;
		last->next = *head_b;
		*head_b = last;
	}
	if (flag)
		write(1, "rrb\n", 4);
}

void	rrr(t_list1 **head_a, t_list1 **head_b)
{
	rra(head_a, 0);
	rrb(head_b, 0);
	write(1, "rrr\n", 4);
}