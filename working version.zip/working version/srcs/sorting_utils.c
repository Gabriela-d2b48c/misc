/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorting_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gabriela <gabriela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/16 11:50:43 by gabriela          #+#    #+#             */
/*   Updated: 2023/04/16 12:00:57 by gabriela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	is_sorted(t_list1 **head_a)
{
	t_list1	*current;

	current = *head_a;
	while (current && current->next)
	{
		if (current->number > current->next->number)
			return (0);
		current = current->next;
	}
	return (1);
}

int	find_smallest(t_list1 **head_a)
{
	t_list1	*current;
	int		smallest;

	current = *head_a;
	smallest = current->number;
	while (current)
	{
		if (current->number < smallest)
			smallest = current->number;
		current = current->next;
	}
	return (smallest);
}

int	find_largest(t_list1 **head)
{
	t_list1	*current;
	int		largest;

	current = *head;
	largest = current->number;
	while (current)
	{
		if (current->number > largest)
			largest = current->number;
		current = current->next;
	}
	return (largest);
}

void	push_smallest(t_list1 **head_src, t_list1 **head_dst)
{
	int	smallest;
	int	size;
	int	i;

	smallest = find_smallest(head_src);
	size = ft_lstsize_push_swap(*head_src);
	i = 0;
	while (i < size)
	{
		if ((*head_src)->number == smallest)
		{
			pb(head_src, head_dst);
			return;
		}
		else
		{
			ra(head_src, 1);
			i++;
		}
	}
}

void	push_largest(t_list1 **head_a, t_list1 **head_b)
{
	int	largest;
	int	size;
	int	i;

	largest = find_largest(head_b);
	size = ft_lstsize_push_swap(*head_b);
	i = 0;
	while (i < size)
	{
		if ((*head_b)->number == largest)
		{
			pa(head_a, head_b);
			return;
		}
		else
		{
			rb(head_b, 1);
			i++;
		}
	}
}
